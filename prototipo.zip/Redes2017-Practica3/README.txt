﻿Integrantes:  
	Angie Daniela Velásquez Garzón
	Bernal Cedillo Enrique Antonio  

Version python: 2.7.12
Version pyaudio 0.2.9
Verion numpy 1.6.1